create definer = root@localhost event batch_add_player_dayrecord on schedule
    every '1' DAY
        starts '2024-01-06 03:00:00'
    on completion preserve
    enable
    do
    INSERT INTO day_behave_recordlist(player_id)
(SELECT player_id FROM player);

